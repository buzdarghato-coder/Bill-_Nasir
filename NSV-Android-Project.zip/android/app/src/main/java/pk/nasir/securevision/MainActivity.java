package pk.nasir.securevision;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
